package com.smartsort.launcher.data

import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.net.Uri
import android.os.UserHandle
import android.provider.Settings
import android.util.Log
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.smartsort.launcher.domain.AppInfo
import com.smartsort.launcher.domain.CategoryClassifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.launch

/**
 * المصدر الوحيد لقائمة التطبيقات (LauncherApps: API رسمي للـ Launchers).
 * كل شيء محلي على الجهاز.
 */
class AppRepository(context: Context) {

    private val ctx = context.applicationContext
    private val launcherApps = ctx.getSystemService(LauncherApps::class.java)
    private val iconPx = (56 * ctx.resources.displayMetrics.density).toInt()

    fun observeApps(): Flow<List<AppInfo>> = callbackFlow {
        fun refresh() {
            launch(Dispatchers.IO) { trySend(loadApps()) }
        }

        val callback = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String?, user: UserHandle?) = refresh()
            override fun onPackageAdded(packageName: String?, user: UserHandle?) = refresh()
            override fun onPackageChanged(packageName: String?, user: UserHandle?) = refresh()
            override fun onPackagesAvailable(
                packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean
            ) = refresh()
            override fun onPackagesUnavailable(
                packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean
            ) = refresh()
        }
        launcherApps.registerCallback(callback)
        refresh()
        awaitClose { launcherApps.unregisterCallback(callback) }
    }.conflate()

    private fun loadApps(): List<AppInfo> {
        return launcherApps.profiles
            .flatMap { user -> launcherApps.getActivityList(null, user) }
            .filter { it.applicationInfo.packageName != ctx.packageName }
            .map { info ->
                val bitmap = info.getIcon(0).toBitmap(iconPx, iconPx)
                val color = IconColor.analyze(bitmap)
                AppInfo(
                    packageName = info.applicationInfo.packageName,
                    className = info.componentName.className,
                    label = info.label?.toString().orEmpty(),
                    icon = bitmap.asImageBitmap(),
                    installTime = info.firstInstallTime,
                    user = info.user,
                    category = CategoryClassifier.classify(info.applicationInfo),
                    hue = color[0],
                    colorful = color[1],
                    lum = color[2],
                )
            }
            .distinctBy { it.key }
    }

    fun launch(app: AppInfo) {
        try {
            launcherApps.startMainActivity(app.component, app.user, null, null)
        } catch (e: Exception) {
            Log.w("AppRepository", "Cannot launch ${app.packageName}", e)
        }
    }

    fun openAppInfo(app: AppInfo) {
        try {
            launcherApps.startAppDetailsActivity(app.component, app.user, null, null)
        } catch (e: Exception) {
            Log.w("AppRepository", "Cannot open info for ${app.packageName}", e)
        }
    }

    fun uninstall(app: AppInfo) {
        startSafely(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
    }

    /** يفتح شاشة اختيار الشاشة الرئيسية (للرجوع إلى الـ Launcher القديم). */
    fun openHomeSettings() {
        val options = listOf(
            Intent(Settings.ACTION_HOME_SETTINGS),
            Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
            Intent(Settings.ACTION_SETTINGS),
        )
        for (intent in options) {
            if (startSafely(intent)) return
        }
    }

    fun openUsageSettings() {
        startSafely(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }

    private fun startSafely(intent: Intent): Boolean {
        return try {
            ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            Log.w("AppRepository", "Cannot start $intent", e)
            false
        }
    }
}
