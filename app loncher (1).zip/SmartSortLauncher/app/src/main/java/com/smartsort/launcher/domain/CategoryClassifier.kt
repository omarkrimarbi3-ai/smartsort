package com.smartsort.launcher.domain

import android.content.pm.ApplicationInfo

/** تصنيف تقريبي: فئة أندرويد الرسمية إن وُجدت، ثم كلمات في اسم الحزمة. */
object CategoryClassifier {

    private val social = listOf(
        "whatsapp", "telegram", "facebook", "instagram", "snapchat", "tiktok", "twitter",
        "discord", "messenger", "reddit", "viber", "signal", "linkedin", "pinterest", "skype",
        "dialer", "contacts", "messaging", "mms", "telecom", "threads", "wechat", "line.android",
    )
    private val videoPhoto = listOf(
        "camera", "gallery", "photos", "capcut", "kinemaster", "alightcreative", "vn.", "inshot",
        "youtube", "netflix", "video", "picsart", "snapseed", "lightroom", "vimeo",
    )
    private val music = listOf("spotify", "music", "deezer", "anghami", "soundcloud", "audio", "podcast", "radio")
    private val productivity = listOf(
        "docs", "sheets", "slides", "office", "notes", "keep", "calendar", "drive", "mail", "gmail",
        "outlook", "notion", "todo", "pdf", "word", "excel", "powerpoint",
    )
    private val tools = listOf(
        "calculator", "clock", "settings", "file", "manager", "weather", "compass", "scanner",
        "cleaner", "vpn", "translate", "maps", "browser", "chrome", "assistant", "recorder", "flashlight",
    )

    @Suppress("DEPRECATION")
    fun classify(info: ApplicationInfo): AppCategory {
        val pkg = info.packageName.lowercase()
        if (info.category == ApplicationInfo.CATEGORY_GAME ||
            (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        ) return AppCategory.GAMES

        if (social.any { pkg.contains(it) }) return AppCategory.SOCIAL
        if (music.any { pkg.contains(it) }) return AppCategory.MUSIC
        if (videoPhoto.any { pkg.contains(it) }) return AppCategory.VIDEO_PHOTO
        if (productivity.any { pkg.contains(it) }) return AppCategory.PRODUCTIVITY
        if (tools.any { pkg.contains(it) }) return AppCategory.TOOLS

        return when (info.category) {
            ApplicationInfo.CATEGORY_SOCIAL -> AppCategory.SOCIAL
            ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> AppCategory.VIDEO_PHOTO
            ApplicationInfo.CATEGORY_AUDIO -> AppCategory.MUSIC
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> AppCategory.PRODUCTIVITY
            ApplicationInfo.CATEGORY_MAPS -> AppCategory.TOOLS
            else -> AppCategory.OTHER
        }
    }
}
