package com.smartsort.launcher.ui.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartsort.launcher.domain.ThemeMode
import com.smartsort.launcher.ui.home.HomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: HomeViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val hasUsage by vm.hasUsageAccess.collectAsStateWithLifecycle()
    val hidden by vm.hiddenApps.collectAsStateWithLifecycle()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.systemBars)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "الإعدادات",
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = { vm.closeAll() }) { Text("✕ إغلاق") }
                }

                Section("الرجوع إلى الشاشة القديمة") {
                    Text(
                        "ترتيب شاشتك القديمة محفوظ كما هو، فـ SmartSort لا يغيّره ولا يحذفه. " +
                            "اضغط الزر ثم اختر الـ Launcher الأصلي للهاتف.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = vm::openHomeSettings, modifier = Modifier.fillMaxWidth()) {
                        Text("العودة إلى الـ Launcher القديم")
                    }
                }

                Section("المظهر") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeMode.values().forEach { mode ->
                            FilterChip(
                                selected = settings.theme == mode,
                                onClick = { vm.setTheme(mode) },
                                label = { Text(mode.title) },
                            )
                        }
                    }
                }

                Section("بيانات الاستخدام") {
                    Text(
                        "تُستخدم فقط لترتيب التطبيقات حسب الأكثر استخدامًا. تبقى على هاتفك ولا تُرسل لأي جهة.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.height(10.dp))
                    if (hasUsage) {
                        Text("✓ مفعّل", color = MaterialTheme.colorScheme.primary)
                    } else {
                        OutlinedButton(onClick = vm::openUsageSettings) {
                            Text("السماح بالوصول لبيانات الاستخدام")
                        }
                        Text(
                            "في الصفحة التي ستفتح: اختر SmartSort ثم فعّل «السماح بالوصول».",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 6.dp),
                        )
                    }
                }

                Section("التطبيقات المخفية") {
                    if (hidden.isEmpty()) {
                        Text("لا توجد تطبيقات مخفية.", style = MaterialTheme.typography.bodyMedium)
                    }
                    hidden.forEach { app ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(36.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(app.label, modifier = Modifier.weight(1f))
                            TextButton(onClick = { vm.toggleHidden(app) }) { Text("إظهار") }
                        }
                    }
                }

                Section("إعادة الضبط") {
                    OutlinedButton(onClick = vm::resetAll) {
                        Text("مسح المفضلة والإخفاء وترتيب المجموعات")
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 24.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        content()
    }
}
