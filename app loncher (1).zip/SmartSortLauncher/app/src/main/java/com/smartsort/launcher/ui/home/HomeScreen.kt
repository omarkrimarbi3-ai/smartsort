package com.smartsort.launcher.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartsort.launcher.domain.FolderUi
import com.smartsort.launcher.ui.components.AppActions
import com.smartsort.launcher.ui.components.AppIcon
import com.smartsort.launcher.ui.components.FolderTile
import com.smartsort.launcher.ui.components.SortChips
import com.smartsort.launcher.ui.drawer.DrawerScreen
import com.smartsort.launcher.ui.settings.SettingsScreen

@Composable
fun HomeScreen(vm: HomeViewModel) {
    val folders by vm.folders.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val drawerOpen by vm.drawerOpen.collectAsStateWithLifecycle()
    val settingsOpen by vm.settingsOpen.collectAsStateWithLifecycle()
    val openFolder by vm.openFolder.collectAsStateWithLifecycle()

    val actions = remember(vm) {
        AppActions(
            open = vm::open,
            toggleFavorite = vm::toggleFavorite,
            toggleHidden = vm::toggleHidden,
            info = vm::appInfo,
            uninstall = vm::uninstall,
        )
    }

    val onSurface = MaterialTheme.colorScheme.onSurface
    val scrim = if (isSystemInDarkTheme()) Color.Black.copy(alpha = 0.45f) else Color.White.copy(alpha = 0.45f)
    var drag by remember { mutableFloatStateOf(0f) }

    Box(
        Modifier
            .fillMaxSize()
            .background(scrim)
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = { if (drag < -160f) vm.openDrawer(false) },
                    onVerticalDrag = { _, dy -> drag += dy },
                )
            }
    ) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 16.dp),
            ) {
                if (favorites.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        SectionTitle("المفضلة")
                    }
                    items(favorites, key = { "f" + it.key }) { app ->
                        AppIcon(app, actions, isFavorite = true)
                    }
                } else {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(
                            text = "اضغط مطولًا على أي تطبيق لإضافته إلى المفضلة",
                            color = onSurface.copy(alpha = 0.7f),
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        )
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    SectionTitle("المجموعات")
                }
                items(folders, key = { "c" + it.category.name }) { folder ->
                    FolderTile(folder, onClick = { vm.openFolder(folder.category) })
                }
            }

            BottomBar(
                onAllApps = { vm.openDrawer(false) },
                onSearch = { vm.openDrawer(true) },
                onSettings = vm::openSettings,
            )
        }

        val currentFolder = folders.firstOrNull { it.category == openFolder }
        if (currentFolder != null) {
            FolderDialog(
                folder = currentFolder,
                actions = actions,
                favoriteIds = settings.favorites,
                onSort = { vm.setFolderSort(currentFolder.category, it) },
                onDismiss = vm::closeFolder,
            )
        }

        if (drawerOpen) {
            DrawerScreen(vm = vm, actions = actions, favoriteIds = settings.favorites)
        }

        if (settingsOpen) {
            SettingsScreen(vm = vm)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
        modifier = Modifier.fillMaxWidth().padding(start = 8.dp, top = 8.dp, bottom = 4.dp),
    )
}

@Composable
private fun BottomBar(onAllApps: () -> Unit, onSearch: () -> Unit, onSettings: () -> Unit) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BarButton("▲", onAllApps)
        Spacer(Modifier.width(10.dp))
        Surface(
            modifier = Modifier.weight(1f).heightIn(min = 48.dp).clickable(onClick = onSearch),
            shape = RoundedCornerShape(28.dp),
            color = onSurface.copy(alpha = 0.14f),
        ) {
            Box(contentAlignment = Alignment.CenterStart, modifier = Modifier.padding(horizontal = 18.dp)) {
                Text("ابحث عن تطبيق", color = onSurface.copy(alpha = 0.8f))
            }
        }
        Spacer(Modifier.width(10.dp))
        BarButton("⚙", onSettings)
    }
}

@Composable
private fun BarButton(symbol: String, onClick: () -> Unit) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    Surface(
        modifier = Modifier.size(48.dp).clickable(onClick = onClick),
        shape = CircleShape,
        color = onSurface.copy(alpha = 0.14f),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(symbol, color = onSurface, style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun FolderDialog(
    folder: FolderUi,
    actions: AppActions,
    favoriteIds: Set<String>,
    onSort: (com.smartsort.launcher.domain.SortMode) -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.94f),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(folder.category.title, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.size(10.dp))
                SortChips(selected = folder.sort, onSelect = onSort)
                Spacer(Modifier.size(8.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.heightIn(max = 440.dp),
                    verticalArrangement = Arrangement.Top,
                ) {
                    items(folder.apps, key = { it.key }) { app ->
                        AppIcon(app, actions, isFavorite = app.id in favoriteIds)
                    }
                }
            }
        }
    }
}
