package com.smartsort.launcher.domain

import android.content.ComponentName
import android.os.UserHandle
import androidx.compose.ui.graphics.ImageBitmap

enum class AppCategory(val title: String) {
    SOCIAL("التواصل"),
    GAMES("ألعاب"),
    VIDEO_PHOTO("فيديو وصور"),
    MUSIC("موسيقى"),
    PRODUCTIVITY("إنتاجية"),
    TOOLS("أدوات"),
    OTHER("أخرى"),
}

enum class SortMode(val title: String) {
    NAME("الاسم"),
    COLOR("اللون"),
    USAGE("الاستخدام"),
}

enum class ThemeMode(val title: String) {
    SYSTEM("النظام"),
    LIGHT("فاتح"),
    DARK("داكن"),
}

data class AppInfo(
    val packageName: String,
    val className: String,
    val label: String,
    val icon: ImageBitmap,
    val installTime: Long,
    val user: UserHandle,
    val category: AppCategory,
    /** لون الأيقونة السائد: درجة اللون 0..360 */
    val hue: Float,
    /** مدى "ألوان" الأيقونة 0..1 (أقل من 0.15 = رمادي/أبيض/أسود) */
    val colorful: Float,
    /** سطوع الأيقونة 0..1 */
    val lum: Float,
) {
    val id: String get() = packageName
    val key: String get() = "$packageName/$className/${user.hashCode()}"
    val component: ComponentName get() = ComponentName(packageName, className)
}

data class FolderUi(
    val category: AppCategory,
    val apps: List<AppInfo>,
    val sort: SortMode,
)

data class Settings(
    val favorites: Set<String> = emptySet(),
    val hidden: Set<String> = emptySet(),
    val folderSort: Map<AppCategory, SortMode> = emptyMap(),
    val theme: ThemeMode = ThemeMode.SYSTEM,
)
