package com.smartsort.launcher.data

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

object IconColor {
    /** يعيد [hue, colorful, lum] لأيقونة. */
    fun analyze(src: Bitmap): FloatArray {
        val size = 16
        val b = Bitmap.createScaledBitmap(src, size, size, true)
        val hsv = FloatArray(3)
        var x = 0.0
        var y = 0.0
        var weightSum = 0.0
        var lumSum = 0.0
        var n = 0
        for (px in 0 until size) {
            for (py in 0 until size) {
                val c = b.getPixel(px, py)
                if (Color.alpha(c) < 128) continue
                Color.colorToHSV(c, hsv)
                val w = (hsv[1] * hsv[2]).toDouble()
                val rad = Math.toRadians(hsv[0].toDouble())
                x += cos(rad) * w
                y += sin(rad) * w
                weightSum += w
                lumSum += hsv[2]
                n++
            }
        }
        if (n == 0) return floatArrayOf(0f, 0f, 0f)
        var hue = Math.toDegrees(atan2(y, x)).toFloat()
        if (hue < 0f) hue += 360f
        return floatArrayOf(hue, (weightSum / n).toFloat(), (lumSum / n).toFloat())
    }
}
