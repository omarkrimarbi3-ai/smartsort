package com.smartsort.launcher.data

import android.content.Context
import com.smartsort.launcher.domain.AppCategory
import com.smartsort.launcher.domain.Settings
import com.smartsort.launcher.domain.SortMode
import com.smartsort.launcher.domain.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** إعدادات المستخدم محفوظة محليًا (SharedPreferences) ولا تغادر الهاتف. */
class SettingsStore(context: Context) {

    private val sp = context.applicationContext.getSharedPreferences("smartsort", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(read())
    val state: StateFlow<Settings> = _state.asStateFlow()

    private fun read(): Settings {
        val sorts = (sp.getStringSet("sorts", emptySet()) ?: emptySet()).mapNotNull { entry ->
            val parts = entry.split("|")
            if (parts.size != 2) return@mapNotNull null
            val category = runCatching { AppCategory.valueOf(parts[0]) }.getOrNull() ?: return@mapNotNull null
            val mode = runCatching { SortMode.valueOf(parts[1]) }.getOrNull() ?: return@mapNotNull null
            category to mode
        }.toMap()
        val theme = runCatching { ThemeMode.valueOf(sp.getString("theme", "SYSTEM") ?: "SYSTEM") }
            .getOrDefault(ThemeMode.SYSTEM)
        return Settings(
            favorites = (sp.getStringSet("fav", emptySet()) ?: emptySet()).toSet(),
            hidden = (sp.getStringSet("hidden", emptySet()) ?: emptySet()).toSet(),
            folderSort = sorts,
            theme = theme,
        )
    }

    private fun update(block: (Settings) -> Settings) {
        val next = block(_state.value)
        _state.value = next
        sp.edit()
            .putStringSet("fav", next.favorites)
            .putStringSet("hidden", next.hidden)
            .putStringSet("sorts", next.folderSort.map { "${it.key.name}|${it.value.name}" }.toSet())
            .putString("theme", next.theme.name)
            .apply()
    }

    fun toggleFavorite(id: String) = update {
        it.copy(favorites = if (id in it.favorites) it.favorites - id else it.favorites + id)
    }

    fun toggleHidden(id: String) = update {
        it.copy(hidden = if (id in it.hidden) it.hidden - id else it.hidden + id)
    }

    fun setFolderSort(category: AppCategory, mode: SortMode) = update {
        it.copy(folderSort = it.folderSort + (category to mode))
    }

    fun setTheme(mode: ThemeMode) = update { it.copy(theme = mode) }

    fun reset() = update { Settings() }
}
