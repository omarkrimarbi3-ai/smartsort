package com.smartsort.launcher.domain

import java.text.Collator

object AppSorter {
    private const val GRAY_LIMIT = 0.15f

    fun sort(apps: List<AppInfo>, mode: SortMode, usage: Map<String, Long>): List<AppInfo> {
        val collator = Collator.getInstance()
        val byName = Comparator<AppInfo> { a, b -> collator.compare(a.label, b.label) }
        return when (mode) {
            SortMode.NAME -> apps.sortedWith(byName)
            SortMode.COLOR -> apps.sortedWith(
                compareBy<AppInfo>(
                    { if (it.colorful < GRAY_LIMIT) 1 else 0 },
                    { if (it.colorful < GRAY_LIMIT) -it.lum else it.hue },
                ).then(byName)
            )
            SortMode.USAGE -> apps.sortedWith(
                compareByDescending<AppInfo> { usage[it.id] ?: 0L }.then(byName)
            )
        }
    }
}
