package com.smartsort.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartsort.launcher.domain.ThemeMode
import com.smartsort.launcher.ui.home.HomeScreen
import com.smartsort.launcher.ui.home.HomeViewModel
import com.smartsort.launcher.ui.theme.SmartSortTheme

class MainActivity : ComponentActivity() {

    private val vm: HomeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        // الضغط على زر Home وأنت داخل SmartSort يغلق كل الشاشات المفتوحة.
        addOnNewIntentListener { vm.closeAll() }

        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            val dark = when (settings.theme) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }
            SmartSortTheme(dark = dark) {
                BackHandler { vm.back() }
                HomeScreen(vm)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshUsage()
    }
}
