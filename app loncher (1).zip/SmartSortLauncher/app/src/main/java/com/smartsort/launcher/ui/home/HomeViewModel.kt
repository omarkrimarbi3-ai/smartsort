package com.smartsort.launcher.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartsort.launcher.data.AppRepository
import com.smartsort.launcher.data.SettingsStore
import com.smartsort.launcher.data.UsageRepository
import com.smartsort.launcher.domain.AppCategory
import com.smartsort.launcher.domain.AppInfo
import com.smartsort.launcher.domain.AppSorter
import com.smartsort.launcher.domain.FolderUi
import com.smartsort.launcher.domain.Settings
import com.smartsort.launcher.domain.SortMode
import com.smartsort.launcher.domain.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AppRepository(application)
    private val store = SettingsStore(application)
    private val usageRepo = UsageRepository(application)

    val settings: StateFlow<Settings> = store.state

    private val _usage = MutableStateFlow<Map<String, Long>>(emptyMap())
    private val _hasUsage = MutableStateFlow(usageRepo.hasPermission())
    val hasUsageAccess: StateFlow<Boolean> = _hasUsage.asStateFlow()

    private val allApps: StateFlow<List<AppInfo>> = repo.observeApps()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val visibleApps: StateFlow<List<AppInfo>> = combine(allApps, settings) { apps, s ->
        apps.filter { it.id !in s.hidden }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val hiddenApps: StateFlow<List<AppInfo>> = combine(allApps, settings) { apps, s ->
        apps.filter { it.id in s.hidden }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val favorites: StateFlow<List<AppInfo>> = combine(visibleApps, settings) { apps, s ->
        AppSorter.sort(apps.filter { it.id in s.favorites }, SortMode.NAME, emptyMap())
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val folders: StateFlow<List<FolderUi>> = combine(visibleApps, settings, _usage) { apps, s, usage ->
        AppCategory.values().mapNotNull { category ->
            val inCategory = apps.filter { it.category == category }
            if (inCategory.isEmpty()) {
                null
            } else {
                val mode = s.folderSort[category] ?: SortMode.NAME
                FolderUi(category, AppSorter.sort(inCategory, mode, usage), mode)
            }
        }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---- الدرج ----
    private val _drawerSort = MutableStateFlow(SortMode.NAME)
    val drawerSort: StateFlow<SortMode> = _drawerSort.asStateFlow()

    val drawerApps: StateFlow<List<AppInfo>> = combine(visibleApps, _drawerSort, _usage) { apps, mode, usage ->
        AppSorter.sort(apps, mode, usage)
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---- الشاشات المفتوحة ----
    private val _drawerOpen = MutableStateFlow(false)
    val drawerOpen: StateFlow<Boolean> = _drawerOpen.asStateFlow()
    var focusSearchOnOpen: Boolean = false
        private set
    private val _settingsOpen = MutableStateFlow(false)
    val settingsOpen: StateFlow<Boolean> = _settingsOpen.asStateFlow()
    private val _openFolder = MutableStateFlow<AppCategory?>(null)
    val openFolder: StateFlow<AppCategory?> = _openFolder.asStateFlow()

    fun openDrawer(focusSearch: Boolean) {
        focusSearchOnOpen = focusSearch
        _drawerOpen.value = true
    }

    fun openSettings() { _settingsOpen.value = true }
    fun openFolder(category: AppCategory) { _openFolder.value = category }
    fun closeFolder() { _openFolder.value = null }

    fun closeAll() {
        _drawerOpen.value = false
        _settingsOpen.value = false
        _openFolder.value = null
    }

    /** زر الرجوع: يغلق آخر شاشة مفتوحة فقط. */
    fun back() {
        when {
            _settingsOpen.value -> _settingsOpen.value = false
            _drawerOpen.value -> _drawerOpen.value = false
            _openFolder.value != null -> _openFolder.value = null
        }
    }

    // ---- الإجراءات ----
    fun open(app: AppInfo) {
        repo.launch(app)
        closeAll()
    }

    fun toggleFavorite(app: AppInfo) = store.toggleFavorite(app.id)
    fun toggleHidden(app: AppInfo) = store.toggleHidden(app.id)
    fun appInfo(app: AppInfo) = repo.openAppInfo(app)
    fun uninstall(app: AppInfo) = repo.uninstall(app)

    fun setFolderSort(category: AppCategory, mode: SortMode) = store.setFolderSort(category, mode)
    fun setDrawerSort(mode: SortMode) { _drawerSort.value = mode }
    fun setTheme(mode: ThemeMode) = store.setTheme(mode)
    fun resetAll() = store.reset()

    fun openHomeSettings() = repo.openHomeSettings()
    fun openUsageSettings() = repo.openUsageSettings()

    fun refreshUsage() {
        viewModelScope.launch(Dispatchers.IO) {
            _hasUsage.value = usageRepo.hasPermission()
            _usage.value = usageRepo.usage()
        }
    }
}
