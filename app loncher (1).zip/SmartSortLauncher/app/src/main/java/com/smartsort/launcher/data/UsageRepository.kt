package com.smartsort.launcher.data

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process

/** بيانات الاستخدام (آخر 30 يومًا). تحتاج صلاحية "الوصول لبيانات الاستخدام" يمنحها المستخدم يدويًا. */
class UsageRepository(context: Context) {

    private val ctx = context.applicationContext

    @Suppress("DEPRECATION")
    fun hasPermission(): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            ctx.packageName,
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** packageName -> إجمالي وقت الاستخدام بالمللي ثانية. */
    fun usage(): Map<String, Long> {
        if (!hasPermission()) return emptyMap()
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val thirtyDays = 30L * 24 * 60 * 60 * 1000
        return try {
            usm.queryAndAggregateUsageStats(now - thirtyDays, now)
                .mapValues { it.value.totalTimeInForeground }
        } catch (e: Exception) {
            emptyMap()
        }
    }
}
