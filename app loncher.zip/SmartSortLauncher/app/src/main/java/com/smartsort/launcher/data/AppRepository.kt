package com.smartsort.launcher.data

import android.content.Context
import android.content.pm.LauncherApps
import android.os.UserHandle
import android.util.Log
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.smartsort.launcher.domain.AppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.launch
import java.text.Collator

/**
 * المصدر الوحيد لقائمة التطبيقات. يستخدم LauncherApps (API رسمي للـ Launchers)
 * ويراقب التثبيت والحذف والتحديث تلقائيًا. كل شيء محلي على الجهاز.
 */
class AppRepository(context: Context) {

    private val ctx = context.applicationContext
    private val launcherApps = ctx.getSystemService(LauncherApps::class.java)
    private val iconPx = (56 * ctx.resources.displayMetrics.density).toInt()

    fun observeApps(): Flow<List<AppInfo>> = callbackFlow {
        fun refresh() {
            launch(Dispatchers.IO) { trySend(loadApps()) }
        }

        val callback = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String?, user: UserHandle?) = refresh()
            override fun onPackageAdded(packageName: String?, user: UserHandle?) = refresh()
            override fun onPackageChanged(packageName: String?, user: UserHandle?) = refresh()
            override fun onPackagesAvailable(
                packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean
            ) = refresh()
            override fun onPackagesUnavailable(
                packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean
            ) = refresh()
        }
        launcherApps.registerCallback(callback)
        refresh()
        awaitClose { launcherApps.unregisterCallback(callback) }
    }.conflate()

    private fun loadApps(): List<AppInfo> {
        val collator = Collator.getInstance()
        return launcherApps.profiles
            .flatMap { user -> launcherApps.getActivityList(null, user) }
            .filter { it.applicationInfo.packageName != ctx.packageName }
            .map { info ->
                AppInfo(
                    packageName = info.applicationInfo.packageName,
                    className = info.componentName.className,
                    label = info.label?.toString().orEmpty(),
                    icon = info.getIcon(0).toBitmap(iconPx, iconPx).asImageBitmap(),
                    installTime = info.firstInstallTime,
                    user = info.user,
                )
            }
            .sortedWith { a, b -> collator.compare(a.label, b.label) }
    }

    fun launch(app: AppInfo) {
        try {
            launcherApps.startMainActivity(app.component, app.user, null, null)
        } catch (e: Exception) {
            Log.w("AppRepository", "Cannot launch ${app.packageName}", e)
        }
    }
}
