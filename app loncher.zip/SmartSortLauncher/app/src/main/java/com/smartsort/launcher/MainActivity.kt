package com.smartsort.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.smartsort.launcher.ui.home.HomeScreen
import com.smartsort.launcher.ui.theme.SmartSortTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            SmartSortTheme {
                BackHandler {} // الـ Launcher لا يُغلق بزر الرجوع
                HomeScreen()
            }
        }
    }
}
